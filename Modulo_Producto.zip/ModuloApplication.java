package com.proyecto1.Modulo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModuloApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModuloApplication.class, args);
	}

}
