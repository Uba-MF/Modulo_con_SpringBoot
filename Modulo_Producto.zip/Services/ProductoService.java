package com.proyecto1.Modulo.Services;

import com.proyecto1.Modulo.Model.Producto;

public interface ProductoService {
    Producto newProducto (Producto newProducto);
    Iterable<Producto> getAll();
    Producto modifyProducto (Producto producto);
    Boolean deleteProducto (int id);
}
