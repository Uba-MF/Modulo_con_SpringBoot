package com.proyecto1.Modulo.Services;

import com.proyecto1.Modulo.Model.Producto;
import com.proyecto1.Modulo.Repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProductoServiceImple implements ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Override
    public Producto newProducto(Producto newProducto) {
        return productoRepository.save(newProducto) ;
    }

    @Override
    public Iterable<Producto> getAll() {
        return this.productoRepository.findAll() ;
    }

    @Override
    public Producto modifyProducto(Producto producto) {

        Optional<Producto> productoEncontrado = this.productoRepository.findById(producto.getId());

        if(productoEncontrado.get()!=null){
            productoEncontrado.get().setNombre(producto.getNombre());
            productoEncontrado.get().setPrecioCompra(producto.getPrecioCompra());
            productoEncontrado.get().setPrecioVenta(producto.getPrecioVenta());
            productoEncontrado.get().setUtilidad(producto.getUtilidad());
            productoEncontrado.get().setStock(producto.getStock());
            productoEncontrado.get().setProveedor(producto.getProveedor());
            return this.newProducto(productoEncontrado.get());
        }
        return null ;
    }

    @Override
    public Boolean deleteProducto(int id) {
        this.productoRepository.deleteById(id);
        return true;
    }
}
