package com.proyecto1.Modulo.Controller;

import com.proyecto1.Modulo.Model.Producto;
import com.proyecto1.Modulo.Services.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Producto")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @PostMapping("/Nuevo")
    public Producto newProducto(@RequestBody Producto newProducto){
    return this.productoService.newProducto(newProducto);
    }

    @GetMapping("/Mostrar")
    public Iterable<Producto> getAll(){
        return productoService.getAll();
    }

    @PostMapping("/Modificar")
    public Producto updateProducto(@RequestBody Producto producto){
        return this.productoService.modifyProducto(producto);
    }

    @PostMapping(value="/(id)")
    public Boolean deleteProducto(@PathVariable(value="id") int id){
        return this.productoService.deleteProducto(id);
    }

}
