package com.proyecto1.Modulo.Model;

// Clase de Java para elaborar la entidad del proyecto

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity // Con esta anotación marca la clase como una entidad
@Data // Genera los métodos necesarios como lo son los Getters y Setters
public class Producto {

    @Id // Anotación para nombrar la clave primaria de la tabla
    @Column
    private int id;
    @Column
    private String nombre;
    @Column
    private int precioCompra;
    @Column
    private int precioVenta;
    @Column
    private int utilidad;
    @Column
    private int stock;
    @Column
    private String proveedor;

    public Producto(){

    }

    public Producto(int id, String nombre, int precioCompra, int precioVenta, int utilidad, int stock, String proveedor) {
        this.id = id;
        this.nombre = nombre;
        this.precioCompra = precioCompra;
        this.precioVenta = precioVenta;
        this.utilidad = utilidad;
        this.stock = stock;
        this.proveedor = proveedor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(int precioCompra) {
        this.precioCompra = precioCompra;
    }

    public int getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(int precioVenta) {
        this.precioVenta = precioVenta;
    }

    public int getUtilidad() {
        return utilidad;
    }

    public void setUtilidad(int utilidad) {
        this.utilidad = utilidad;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }
}
