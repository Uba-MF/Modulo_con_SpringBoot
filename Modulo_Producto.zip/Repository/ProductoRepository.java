package com.proyecto1.Modulo.Repository;

import com.proyecto1.Modulo.Model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {

}
